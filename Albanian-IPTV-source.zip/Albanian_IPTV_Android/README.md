# Albanian IPTV – Android starter project

A starter Android app named **Albanian IPTV**. It can load a user-provided M3U/M3U8 playlist URL, display the channels, and play a selected stream.

## Open in Android Studio
1. Upload this project folder's contents to a GitHub repository (or upload the ZIP and extract it first).
2. In Android Studio choose **Open** and select the `Albanian_IPTV_Android` folder.
3. Allow Gradle sync to finish.
4. Connect an Android phone with USB debugging enabled, or use an emulator, then press **Run**.

## Features
- App name: Albanian IPTV
- M3U playlist URL loading
- Basic channel list
- HLS/M3U8 playback through AndroidX Media3 / ExoPlayer

## Important
- This is a starter project, not a finished commercial IPTV service.
- It does not include channels, subscriptions, or playlist credentials. Add only playlists and streams you are authorized to use.
- Some providers require extra authentication or headers; this starter app does not implement provider-specific login.
- A working APK must be built with Android Studio or a compatible Android build service.
