package com.albanianiptv.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

data class Channel(val name: String, val streamUrl: String)

class MainActivity : Activity() {
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var playlistInput: EditText
    private lateinit var status: TextView
    private lateinit var channelList: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 16, 24)
        window.navigationBarColor = Color.BLACK

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 18, 16, 12)
            setBackgroundColor(Color.rgb(12, 16, 24))
        }

        val heading = TextView(this).apply {
            text = "ALBANIAN IPTV"
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 16)
        }
        root.addView(heading)

        playlistInput = EditText(this).apply {
            hint = "Indsæt M3U / M3U8 playlist-link"
            setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE)
            textSize = 14f
            singleLine = true
            setPadding(12, 8, 12, 8)
            setBackgroundColor(Color.rgb(35, 42, 54))
        }
        root.addView(playlistInput, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        val loadButton = Button(this).apply {
            text = "HENT KANALER"
            setOnClickListener { loadPlaylist(playlistInput.text.toString().trim()) }
        }
        root.addView(loadButton)

        status = TextView(this).apply {
            text = "Indsæt et playlist-link for at hente dine kanaler."
            setTextColor(Color.LTGRAY)
            textSize = 13f
            setPadding(0, 8, 0, 8)
        }
        root.addView(status)

        playerView = PlayerView(this).apply {
            useController = true
        }
        root.addView(playerView, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(220)
        ))

        val listTitle = TextView(this).apply {
            text = "KANALER"
            textSize = 17f
            setTextColor(Color.WHITE)
            setPadding(0, 14, 0, 8)
        }
        root.addView(listTitle)

        val scroll = ScrollView(this)
        channelList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(channelList)
        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        setContentView(root)
        player = ExoPlayer.Builder(this).build()
        playerView.player = player
    }

    private fun loadPlaylist(link: String) {
        if (link.isBlank() || !(link.startsWith("https://") || link.startsWith("http://"))) {
            status.text = "Indtast et gyldigt http(s) playlist-link."
            return
        }
        status.text = "Henter playlist..."
        channelList.removeAllViews()
        thread {
            try {
                val connection = (URL(link).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 15000
                    readTimeout = 20000
                    setRequestProperty("User-Agent", "AlbanianIPTV/1.0")
                }
                val content = connection.inputStream.bufferedReader().use { it.readText() }
                connection.disconnect()
                val channels = parseM3u(content)
                runOnUiThread {
                    channelList.removeAllViews()
                    if (channels.isEmpty()) {
                        status.text = "Ingen kanaler fundet. Kontrollér playlist-linket."
                    } else {
                        status.text = "${channels.size} kanaler fundet."
                        channels.forEach { channel ->
                            val button = Button(this).apply {
                                text = channel.name
                                isAllCaps = false
                                setOnClickListener { play(channel) }
                            }
                            channelList.addView(button)
                        }
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Kunne ikke hente playlist: ${e.localizedMessage ?: "ukendt fejl"}" }
            }
        }
    }

    private fun parseM3u(text: String): List<Channel> {
        val result = mutableListOf<Channel>()
        var nextName = "Kanal"
        text.lineSequence().forEach { raw ->
            val line = raw.trim()
            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    nextName = line.substringAfterLast(",").trim().ifBlank { "Kanal" }
                }
                line.isNotBlank() && !line.startsWith("#") &&
                    (line.startsWith("http://") || line.startsWith("https://")) -> {
                    result.add(Channel(nextName, line))
                    nextName = "Kanal"
                }
            }
        }
        return result
    }

    private fun play(channel: Channel) {
        status.text = "Afspiller: ${channel.name}"
        player?.setMediaItem(MediaItem.fromUri(channel.streamUrl))
        player?.prepare()
        player?.play()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        playerView.player = null
        player?.release()
        player = null
        super.onDestroy()
    }
}
